package org.study.jdbc;

public class Test1201 {

	public static void main(String[] args) {
		
		
		
		
	}
}
