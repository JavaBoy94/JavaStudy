package org.study.commend;

public interface DBCommend {
// DB에 쿼리문에 맞는 작업을 수행할 인터페이스 세팅 
// CRUD 클래스에서 DBCommend 오버라이드하여 메소드 세팅
	void excuteQueryCommend();
	
}
